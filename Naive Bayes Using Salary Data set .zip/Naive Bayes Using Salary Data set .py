#!/usr/bin/env python
# coding: utf-8

# In[5]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

### Data Set Uplode###
Salary_Train=pd.read_csv("C:\\Users\\Admin\Downloads\\SalaryData_Train.csv")
SalaryData_Test=pd.read_csv("C:\\Users\\Admin\\Downloads\\SalaryData_Test.csv")
Salary_Train.columns
SalaryData_Test.columns
string_columns=['workclass','education','maritalstatus','occupation','relationship','race','sex','native']


#### Data Preprocessing###

from sklearn import preprocessing
label_encoder=preprocessing.LabelEncoder()
for i in string_columns:
    Salary_Train[i]=label_encoder.fit_transform(Salary_Train[i])
    SalaryData_Test[i]=label_encoder.fit_transform(SalaryData_Test[i])
    
##### Data Spilting####
col_names=list(Salary_Train.columns)
Train_X=Salary_Train[col_names[0:13]]
Train_Y=Salary_Train[col_names[13]]
Test_x=SalaryData_Test[col_names[0:13]]
Test_y=SalaryData_Test[col_names[13]]

######### Naive Bayes ##############

#Gaussian Naive Bayes

from sklearn.naive_bayes import GaussianNB
Gmodel=GaussianNB()
Train_pred_gau=Gmodel.fit(Train_X,Train_Y).predict(Train_X)
Test_pred_gau=Gmodel.fit(Train_X,Train_Y).predict(Test_x)

Train_acc_gau=np.mean(Train_pred_gau==Train_Y)
Test_acc_gau=np.mean(Test_pred_gau==Test_y)
Train_acc_gau#0.795
Test_acc_gau#0.794

#Multinomial Naive Bayes

from sklearn.naive_bayes import MultinomialNB
Mmodel=MultinomialNB()
Train_pred_multi=Mmodel.fit(Train_X,Train_Y).predict(Train_X)
Test_pred_multi=Mmodel.fit(Train_X,Train_Y).predict(Test_x)

Train_acc_multi=np.mean(Train_pred_multi==Train_Y)
Test_acc_multi=np.mean(Test_pred_multi==Test_y)
Train_acc_multi#0.772
Test_acc_multi#0.774

